package series_de_taylor;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Series_De_Taylor {
    
    //Trabajo realizado por David Hernandez
    //ID: 670809
    //NRC: 7478
    //Docente: Alonso Guevara Perez
    //Link del repositorio de GitHub: https://github.com/David-Hern/Serie_Taylor.git

    public static void main(String[] args) {
        Scanner Leer = new Scanner (System.in);
        
        boolean salir = false;
        
        while(!salir){
            
            System.out.println(" .: MENU :.\n");
            System.out.println("1. Mostrar serie de Taylor - X^n");
            System.out.println("2. Mostrar serie de Taylor - SENO");
            System.out.println("3. Mostrar serie de Taylor - COSENO");
            System.out.println("4. Mostrar serie de Taylor - PI (π) ");
            System.out.println("5. Salir \n");
            
            try{
            
                System.out.println("SELECCIONE UNA OPCIÓN");
                int opcion = Leer.nextInt();

                switch (opcion){

                    case 1: 
                        //Datos de entrada
                        System.out.println("Ingrese una cantidad: ");
                        int n = Leer.nextInt();
                        System.out.println("Ingrese el valor de X: ");
                        int x = Leer.nextInt();

                        //Realización del cálculo
                        double s = 0, t;
                        for (int i = 0; i < n; i++) {
                            t = Math.pow (x,i) / factorial (i);
                            s = s+t;

                        }

                        //Resultados
                        System.out.printf("f(%d)=%f\n", x, s);

                        break;

                    case 2:
                        //Datos de entrada
                        System.out.println("Ingrese una cantidad: ");
                        int N = Leer.nextInt();
                        System.out.println("Ingrese el valor de X: ");
                        int X = Leer.nextInt();

                        //Realización del cálculo
                        int i = 1, fact =1, j=1;
                        double sen =0;

                        while(i<N){
                            while(j<(1+(2*(i-1)))){
                                fact = fact *j;
                                j++;
                            }
                            if (i%2 == 0){
                                sen = sen -(Math.pow(X,(1+(2*(i-1))))/fact);
                            }else{
                                sen = sen + (Math.pow(X,(1+(2*(i-1))))/fact);
                                i++;
                            }
                            //Resultados
                            System.out.println("El resultado es: " +sen);
                        }
                        break;

                    case 3: 
                        //Datos de entrada
                        System.out.println("Ingrese una cantidad: ");
                        int nn = Leer.nextInt();
                        System.out.println("Ingrese el valor de X: ");
                        int xx = Leer.nextInt();

                        //Realización del cálculo
                        double ss = 0;
                        int signo = 1;
                        for (int k = 0; k < nn; k+=2) {
                            ss = ss+signo*Math.pow(xx,k) / factorial_2(k);
                            signo = signo * -1;
                        }
                        //Resultados
                        System.out.printf("f(%d)=%f", xx, ss);
                    break;

                    case 4:
                        //Datos de entrada
                        System.out.println("¿Con cuantos terminos de presicion desea que se realice el calculo?");
                        int precision = Leer.nextInt();

                        //Realización del cálculo
                        System.out.println("PI (π) = "+pi(precision));
                        break;

                    case 5:
                        salir = true;
                        break;

                    default:
                        System.out.println("SELECCIONE UNA OPCION VALIDA");
                }
                
            }catch (InputMismatchException e){
                System.out.println("La opcion debe ser un numero");
                Leer.next();
                
            }
        }
        System.out.println("GRACIAS POR UTILIZAR EL PROGRAMA");
        
        
    }
    public static double factorial (int n){
        double aux = 1;
        for (int i = 2; i <= n; i++) {
            aux = aux*i;
        }
        return aux;
    }
    public static double factorial_2 (int nn){
        double factorial_2 = 1.0d;
        
        while (nn !=0){
            factorial_2 = factorial_2 * nn--;
        }
        return factorial_2;
    }
    public static double pi(int precision){
        int d = 1, sig = 1;
        double t, s = 0;
        
        for (int i = 1; i <= precision; i++) {
            t = (double) 1/d*sig;
            s = s+t;
            d = d+2;
            sig = sig*-1;
        }
        return s*4;
    }
    
}
